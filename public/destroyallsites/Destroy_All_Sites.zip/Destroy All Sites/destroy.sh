#!/usr/bin/env bash
# This script will change 3 Safari Preferences in the General section ("New 
# Windows Open With", "New Tabs Open With", "Top Sites Shows") and, after 
# making a backup, will replace your current Top Sites with new ones.

read -p "Replace Top Sites with science (y/n)?: " -n 1 input

if [[ "$input" = "y" || "$input" = "Y" ]]; then

	# Path Variables
	safariPath="/Library/Preferences/com.apple.Safari.plist"
	topSitesPath="/Library/Safari/TopSites.plist"
	plistUrl="http://distantfuturejosh.com/destroyallsites/theme/mars/TopSites.plist"
	
	# Convert plist to readable format
	plutil -convert xml1 $HOME$safariPath
	
	# Modify Top Sites Grid pref
	grid=$(grep -n "TopSitesGridArrangement" $HOME$safariPath | sed -e 's/:.*//g')
	gridVal=$(( $grid+1 ))
	sed -i '' $gridVal's/[0-9]/\0/g' $HOME$safariPath
	
	# Modify New Window pref
	window=$(grep -n "NewWindowBehavior" $HOME$safariPath | sed -e 's/:.*//g')
	windowVal=$(( $window+1 ))
	sed -i '' $windowVal's/[0-9]/4/g' $HOME$safariPath
	
	# Modify New Tab pref
	tab=$(grep -n "NewTabBehavior" $HOME$safariPath | sed -e 's/:.*//g')
	tabVal=$(( $tab+1 ))
	sed -i '' $tabVal's/[0-9]/4/g' $HOME$safariPath
	
	# Convert plist back to binary, make changes stick by reading them
	plutil -convert binary1 $HOME$safariPath
	defaults read com.apple.Safari
	
	# Make backup of Top Sites, download new and replace
	cp $HOME$topSitesPath $HOME/Library/Safari/TopSites\(backup\).plist
	curl -o $HOME$topSitesPath $plistUrl
	
	# Success message
	echo -e "\nRestart Safari and enjoy. Science may take a moment to load."
	
elif [[ "$input" = "n" || "$input" = "N" ]]; then
	echo -e "\nNo science was done."
	exit 0
else
	echo -e "\nInvalid. Aborting..."
	exit 0
fi
